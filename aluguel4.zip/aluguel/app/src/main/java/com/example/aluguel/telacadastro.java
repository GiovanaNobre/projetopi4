package com.example.aluguel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class telacadastro extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_telacadastro);
    }
}
